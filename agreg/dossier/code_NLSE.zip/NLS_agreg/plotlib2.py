




#%% Plot temporal and spectral intensity profile at given distance
plottz2(616, t, N_Long_plot, mat_time, -1e-10, 1e-10,1000) # plott(figure number, t vector, z vector, field matrix, t min, t max, z)


#%% Plot temporal intensity profile at given distance
plott2(616, t, N_Long_plot, mat_time, -1e-10, 1e-10, 0) # plott(figure number, t vector, z vector, field matrix, t min, t max, z)