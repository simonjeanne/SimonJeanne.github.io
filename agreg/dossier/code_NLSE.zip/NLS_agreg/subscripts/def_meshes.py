c                   = 3e8
h                   = 6.62e-34
dt                  = tmax/Npoints
t                   = np.arange(0, tmax, dt, dtype=float)
t                   = t - np.mean(t)
freq                = np.fft.fftshift(np.fft.fftfreq(Npoints))/tmax*Npoints
om                  = 2*np.pi*freq
f                   = freq
df                  = f[2]-f[1]
N_Long              = np.linspace(0, L, np.int(L/dz+1))