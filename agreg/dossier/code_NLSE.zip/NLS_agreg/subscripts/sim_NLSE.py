Psifreq         = nls.fft(Psi)

#%% Noise
if noise == 1:
    Pphoton             = 1e-5
    bruit_FT            = np.fft.fftshift(np.fft.fft(np.sqrt(Pphoton)*(np.random.normal(0, 1, Npoints) + 1j*2*np.pi*np.random.rand(Npoints))/2, norm='ortho'))
    Ufreq               = bruit_FT + Ufreq
    U                   = nls.ifft(Ufreq)

#%% Initiate matrices
mat_freq    = Psifreq
mat_time    = Psi
N_Long_plot = 0

#%% Simulation
coef_lin    = ((beta2/2)*om**2)*(dz/2)
N_Long      = np.linspace(0, L, np.int(L/dz+1))
start_time  = time.time()
step        = 0

for m in range(N_Long.size-1):
    
    Psifreq        = nls.split_step(Psifreq, dz, coef_lin, alpha, gamma)
    Psi            = nls.ifft(Psifreq)
    
    step         += 1
    if step == L/z_record/dz:
        mat_freq    = np.c_[mat_freq, Psifreq]
        mat_time    = np.c_[mat_time, Psi]
        N_Long_plot = np.append(N_Long_plot, (m+1)*dz)
        step        = 0
        prog = (m+1)*dz/L*100
        print("%f" % prog)

print("--- %s seconds ---" % (time.time() - start_time))