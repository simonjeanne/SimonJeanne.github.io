import numpy as np

def split_step(Psifreq, dz, coef_lin, alpha, gamma):
    Psifreq        = np.exp(1j*coef_lin - alpha/2*(dz/2))*Psifreq # 1/2 pas linéaire
    Psi            = np.fft.ifft(np.fft.fftshift(Psifreq), norm='ortho')              
    Psi            = np.exp(1j*gamma*np.abs(Psi)**2)*Psi # 1 pas nonlinéaire
    Psifreq        = np.fft.fftshift(np.fft.fft(Psi, norm='ortho'))
    Psifreq        = np.exp(1j*coef_lin - alpha/2*(dz/2))*Psifreq # 1/2 pas linéaire
    return Psifreq
    
#def RK(gam, dzz, Un):
 #   k1 = rhs(gam, Un)
  #  k2 = rhs(gam, Un + k1*dzz/2)
   # k3 = rhs(gam, Un + k2*dzz/2)
    #k4 = rhs(gam, Un + k3*dzz)
    #return Un + (k1 + 2*k2 + 2*k3 + k4)*dzz/6

def rhs(gam, Unn):
    return 1j*gam*Unn*np.abs(Unn)**2

def fft(E):
    return np.fft.fftshift(np.fft.fft(E, norm='ortho'))

def ifft(Ef):
    return np.fft.ifft(np.fft.fftshift(Ef), norm='ortho')