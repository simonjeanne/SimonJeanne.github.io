import numpy as np
import matplotlib.pyplot as plt





def plott2(num, t, N_Long_plot, mat_field_time, mini, maxi, dist):
    
    """ plott(figure number, t vector, z vector, field matrix, t min, t max, z) """
    
    ind_dist = min(np.argwhere(N_Long_plot >= dist))
    plt.figure(num)
    plt.plot(t, np.abs(mat_field_time[:, ind_dist])**2,'r')
    plt.xlim(mini, maxi)
    plt.ylim(0, 1.1*np.max(np.abs(mat_field_time[:, ind_dist])**2))
    plt.xlabel("temps (s)")
    plt.ylabel("Puissance (W)")
    st = "Profil de puissance en entrée de fibre (ligne pleine) et en sortie (ligne pointillée)" 
    plt.title(st)
    
    
    

def plottz2(num, t, N_Long_plot, mat_field_time, mini, maxi, dist):
    
    """ plott(figure number, t vector, z vector, field matrix, t min, t max, z) """
    
    ind_dist = min(np.argwhere(N_Long_plot >= dist))
    plt.figure(num)
    plt.plot(t, np.abs(mat_field_time[:, ind_dist])**2,'b--',dashes=(5, 5))
    plt.xlim(mini, maxi)
    plt.ylim(0, 1.1*np.max(np.abs(mat_field_time[:, ind_dist])**2))
    plt.xlabel("temps (s)")
    plt.ylabel("Puissance (W)")
    st = "Profil de puissance en entrée de fibre (ligne pleine) et en sortie (ligne pointillée)" 
    plt.title(st)
    
    
