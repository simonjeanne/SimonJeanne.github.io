###############################################################################

###############################################################################
import numpy as np
import time
import subscripts.functions_for_NLSE as nls
from subscripts.plotfcn import plott
from subscripts.plotfcn import plottz
from subscripts.plotfcn2 import plott2
from subscripts.plotfcn2 import plottz2


#%% Parameters
power         = 1
Tlmh          = 10e-12
T0          = Tlmh/2*np.sqrt(2*np.log(2)) #ATTENTION PARENTHESES A AJOUTER
beta2         = -19e-27
gamma         = 0
alpha        = 0
L             = 10000              # Propagation distance

Npoints       = 2**14                 # number of points for the field
tmax          = 1e-9                   # temporal window extent
dz            = 1                # integration step
z_record      = 100                # Number of recorded traces
noise         = 0

exec(open("subscripts/def_meshes.py").read())

#%% Initial field 
Psi             = np.ones(Npoints)*np.sqrt(power)*np.exp(-(t**2/(2*T0**2)))



#%% Start simulation
exec(open("subscripts/sim_nlse.py").read())

exec(open("plotlib.py").read())

#Tfwhm = 1e-11
#T0 = Tfwhm/(2*np.log(1+np.sqrt(2)))
#Psi             = np.ones(Npoints)*np.sqrt(power)/(np.cosh(t/T0))



#%% Start simulation
#exec(open("subscripts/sim_nlse.py").read())

#exec(open("plotlib2.py").read())


