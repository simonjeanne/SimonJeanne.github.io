#include<iostream>
#include<cmath>
#include<fstream>
#include<sstream>
#include<iomanip>
#include<stdlib.h>
#include <string>
#include <complex>
#include <stdio.h>

#include  <string.h>


using namespace std;



#define theta  1.  // temps carac de formation du produit
#define taux_expl  0.5 // taux d'exploitation


#define temps_production_incompressible 0.3
#define capital_fixe_incompressible 2.
#define capital_variable_incompressible 0.4

#define capitale_fixe_compressible 0.5
#define capitale_variable_compressible 0.1





//FONCTION
//FONCTION
//FONCTION
double efficacite(double Delta_t)  //efficacite de production (de 0 à 1)
{ double eff = 1-exp(-Delta_t/theta);
  return eff;
}



double capital_constant(double Delta_t) //capital constant investi pour 
{ double C=capital_fixe_incompressible + capitale_fixe_compressible*Delta_t;
  return C;
}


double capital_variable(double Delta_t) //capital constant investi pour 
{ double V=capital_variable_incompressible + capitale_variable_compressible*Delta_t;
  return V;
}


double temps_rotation(double Delta_t) 
{ double T=temps_production_incompressible+Delta_t; 
  return T;
}



double valeur_produit( double ** Liste_INDUSTRIEL, int n) //valeur par unité de produit en fonction de la prod totale
{ double val_prod = 0.;
  double quantite_produit = 0.;
  double Delta_t;
  for(int i=0;i<n;i++)
  { Delta_t = Liste_INDUSTRIEL[i][0];
    val_prod = val_prod + (capital_constant(Delta_t) + capital_variable(Delta_t)/taux_expl) /temps_rotation(Delta_t); 
    quantite_produit = quantite_produit + efficacite(Delta_t)/temps_rotation(Delta_t); 
  }
  val_prod = val_prod/quantite_produit;
  return val_prod;
}


double valeur_produit_individuel( double * INDUSTRIEL ) //valeur par unité de produit si l'industriel était seul sur le marché
{ double val_prod = 0.;
  double Delta_t;
  Delta_t = INDUSTRIEL[0];
  val_prod = ( ( capital_constant(Delta_t) + capital_variable(Delta_t)/taux_expl ) )/efficacite(Delta_t) ;
  return val_prod;
}


double taux_de_profit( double * INDUSTRIEL, double val_prod )
{ double Delta_t = INDUSTRIEL[0];
  //double taux_profit = 1./temps_rotation(Delta_t)*log( efficacite(Delta_t)*val_prod/(capital_constant(Delta_t)+capital_variable(Delta_t)) );
  double taux_profit = pow(efficacite(Delta_t)*val_prod/(capital_constant(Delta_t)+capital_variable(Delta_t)),1./temps_rotation(Delta_t));
  taux_profit = 100.*(taux_profit-1.); // conversion poucentage
  return taux_profit;
}



double Delta_t_optimal( double ** liste_INDUSTRIEL, int n )   // recherche meilleur Delta_t (au sens du profit) parmis les industriels 
{ double test = 0.; double Delta_t_opt;
  for(int i=0;i<n;i++)
  { if( liste_INDUSTRIEL[i][1]>test )
    { test = liste_INDUSTRIEL[i][1]; 
      Delta_t_opt = liste_INDUSTRIEL[i][0];
    }
  }
  return Delta_t_opt;
}






double Prix( double Delta_t ) //Prix (production unifié)
{ return ((capital_constant(Delta_t) + capital_variable(Delta_t)/taux_expl))/efficacite(Delta_t); }




double RECHERCHE_MAX_PRODUCTIVITE()   // recherche meilleur Delta_t (au sens de la productivité)
{ double test;
  double Delta_t_max_produ;
  int n=100; int i,j;
  double ** INDUSTRIEL = new double*[n];
  for(i=0;i<n;i++) 
  { INDUSTRIEL[i] = new double[2]; 
    INDUSTRIEL[i][0] = 0.1*i;
  }
  for(j=0;j<100;j++)
  { test = 10000000000.;
    for(i=0;i<n;i++) 
    { INDUSTRIEL[i][1] = valeur_produit_individuel( INDUSTRIEL[i] );
      if( INDUSTRIEL[i][1]<test )
      { test = INDUSTRIEL[i][1]; Delta_t_max_produ=INDUSTRIEL[i][0]; }
    }
    for(i=0;i<n;i++)
    { INDUSTRIEL[i][0] = (INDUSTRIEL[i][0]+Delta_t_max_produ)/2.; }  
  }
  return Delta_t_max_produ;
}

//FONCTION
//FONCTION
//FONCTION










int main()
{ int i,j;
  double Delta_t;

  cout << RECHERCHE_MAX_PRODUCTIVITE() << "  " << Prix( RECHERCHE_MAX_PRODUCTIVITE() ) << endl;

  ofstream w_prod("courbe_productivite.txt",ios::out);
  w_prod.precision(12);
  w_prod << setw(15) << "Delta_t" << setw(15) << "Prix" << endl;
  for(i=1;i<1000;i++)
  { Delta_t=0.01*i;
    w_prod << setw(15) << Delta_t << setw(15) << Prix(Delta_t) << endl;
  }
  w_prod.close();
  

  int n = 10;
  double ** liste_INDUSTRIEL = new double*[n];
  double ** liste_INDUSTRIEL_SAVE = new double*[n];
  for(i=0;i<n;i++)
  { liste_INDUSTRIEL[i] = new double[2];
    liste_INDUSTRIEL_SAVE[i] = new double[2];
    liste_INDUSTRIEL[i][0] = 0.3*(i+2);
    liste_INDUSTRIEL[i][1] = 0.;
  }

  double val_prod = valeur_produit( liste_INDUSTRIEL, n);



  ofstream w_baisse("profit_et_prix_globaux.txt",ios::out);
  w_baisse.precision(12);
  w_baisse << setw(20) << "iteration" << setw(20) << "taux profit global" << setw(20) << "Prix" << endl;

  double test = 0;
  double Delta_t_opt;
  double taux_profit_global=0.;
  for(i=0;i<n;i++)
  { liste_INDUSTRIEL[i][1] = taux_de_profit( liste_INDUSTRIEL[i], val_prod );
    taux_profit_global=taux_profit_global+liste_INDUSTRIEL[i][1];
  }
  taux_profit_global=taux_profit_global/n;
  w_baisse << setw(20) << 0 << setw(20) << taux_profit_global << setw(20) << val_prod << endl;
  Delta_t_opt = Delta_t_optimal( liste_INDUSTRIEL, n );
  //cout << "val prod  " << val_prod << "  Delta_t_opt  " << Delta_t_opt << endl;



  ofstream res("res.txt",ios::out);
  res.precision(12);
  res << "Valeur Produit = " << val_prod << endl;
  res << setw(20) << "Delta_t" << setw(20) << "Taux_profit" << setw(20) << "Prix (ind)" << setw(20) << "n_iteration" << setw(20) << "n_industriel" << endl;
  for(i=0;i<n;i++) 
  { res << setw(20) << liste_INDUSTRIEL[i][0] << setw(20) << liste_INDUSTRIEL[i][1] << setw(20) << Prix( liste_INDUSTRIEL[i][0] ) << setw(20) << 0 <<  setw(20) << i << endl; }


  string nom_fichier;
  for(j=1;j<1000;j++)
  { for(i=0;i<n;i++)
    { liste_INDUSTRIEL_SAVE[i][0] = liste_INDUSTRIEL[i][0]; }
    for(i=1;i<n-1;i++)
    { if(liste_INDUSTRIEL[i][0]>Delta_t_opt) { liste_INDUSTRIEL[i][0]=(liste_INDUSTRIEL_SAVE[i-1][0]+liste_INDUSTRIEL_SAVE[i][0])/2.; }
      if(liste_INDUSTRIEL[i][0]<Delta_t_opt) { liste_INDUSTRIEL[i][0]=(liste_INDUSTRIEL_SAVE[i+1][0]+liste_INDUSTRIEL_SAVE[i][0])/2.; }
    }
    if( liste_INDUSTRIEL[0][0]<Delta_t_opt ) { liste_INDUSTRIEL[0][0]=(liste_INDUSTRIEL_SAVE[1][0]+liste_INDUSTRIEL_SAVE[0][0])/2.; }
    else { liste_INDUSTRIEL[0][0]=2*liste_INDUSTRIEL_SAVE[0][0]-liste_INDUSTRIEL_SAVE[1][0]; }
    if( liste_INDUSTRIEL[n-1][0]>Delta_t_opt ) { liste_INDUSTRIEL[n-1][0]=(liste_INDUSTRIEL_SAVE[n-1][0]+liste_INDUSTRIEL_SAVE[n-2][0])/2.; }
    else { liste_INDUSTRIEL[n-1][0]=2*liste_INDUSTRIEL_SAVE[n-1][0]-liste_INDUSTRIEL_SAVE[n-2][0]; }
    val_prod = valeur_produit( liste_INDUSTRIEL, n);
    taux_profit_global = 0;
    for(i=0;i<n;i++)
    { liste_INDUSTRIEL[i][1] = taux_de_profit( liste_INDUSTRIEL[i], val_prod );
      taux_profit_global=taux_profit_global+liste_INDUSTRIEL[i][1];
    }
    taux_profit_global=taux_profit_global/n;
    w_baisse << setw(20) << j << setw(20) << taux_profit_global << setw(20) << val_prod << endl;
    Delta_t_opt = Delta_t_optimal( liste_INDUSTRIEL, n );
    //cout << "val prod  " << val_prod << "  Delta_t_opt  " << Delta_t_opt << endl;
    nom_fichier = "res_" + to_string(j) + ".txt" ;
    res << " " << endl;
    res << "Valeur Produit = " << val_prod << endl;
    for(i=0;i<n;i++) 
    { res << setw(20) << liste_INDUSTRIEL[i][0] << setw(20) << liste_INDUSTRIEL[i][1] << setw(20) << Prix( liste_INDUSTRIEL[i][0] ) << setw(20) << j <<  setw(20) << i << endl;
    }
  }

   res.close();
   w_baisse.close();


// Creation des images necessaires aux animations
  ofstream gnu("affichage.gnu",ios::out);

   for(i=0;i<30;i++)
  {
    gnu << "set border lw 4" << endl;
    gnu << "unset key" << endl;
    gnu << "set lmargin 10" << endl;
    gnu << "set grid" << endl;
    gnu << "set term png size 1440,1000" << endl;
    gnu << "set tics font ',20'" << endl;
    gnu << "set output 'image_" << i << ".png'" << endl;
    gnu << "set xrange[0:4]" << endl;
    gnu << "set yrange[4:8]" << endl;
    gnu << "set xlabel 'Durée de la Réaction' font ',20'" << endl;
    gnu << "set ylabel 'Prix du Produit (rouge) / coût environnemental (vert)' font ',20'" << endl;
    gnu << "plot 'courbe_productivite.txt' using 1:2 w l lw 3, 'res.txt' using 1:($4==" << i << "?$3:1/0) pt 5 ps 2 lc 'blue', 0.75*(5+0.4*x)/(1.-exp(-x)) w l lc 'green' lw 2, 'profit_et_prix_globaux.txt' using (1.93685):(4.85579) pt 7 ps 3 lc 'red', 'profit_et_prix_globaux.txt' using (2.79):(4.8872) pt 7 ps 3 lc 'green'" << endl;
    gnu << " " << endl;

    gnu << "set xrange[0:30]" << endl;
    gnu << "set yrange[4.9:5.4]" << endl;
    gnu << "set ylabel 'Prix du marché' font ',20' " << endl;
    gnu << "set xlabel 'Itération' font ',20'" << endl;
    gnu << "set output 'graphe_" << i << ".png'" << endl;
    gnu << "plot 'profit_et_prix_globaux.txt' using 1:3 w l lw 3, 'profit_et_prix_globaux.txt' every ::" << i+1 << "::" << i+1 << " using 1:3 pt 9 ps 3 lc 'blue'" << endl;
    gnu << " " << endl;
  }
  


  gnu.close();
  system( "gnuplot affichage.gnu" ); 
// Creation des images necessaires aux animations


  return 0;
}



