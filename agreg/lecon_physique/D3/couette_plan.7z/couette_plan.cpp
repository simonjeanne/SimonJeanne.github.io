#include<iostream>
#include<cmath>
#include<fstream>
#include<sstream>
#include<iomanip>
#include<stdlib.h>
#include <string>
#include <complex>
#include <stdio.h>



using namespace std;


void choc_deux_particule(double * particule_1, double * particule_2)
{ //vitesse du centre de masse
  double vgx = 0.5*(particule_1[2]+particule_2[2]);
  double vgy = 0.5*(particule_1[3]+particule_2[3]);
  //vitesse et direction ds le ref du centre de masse
  double vitesse_ = sqrt((particule_1[2]-vgx)*(particule_1[2]-vgx) + (particule_1[3]-vgy)*(particule_1[3]-vgy));
  double theta = 2*M_PI*rand()/RAND_MAX;
  //vitesse après colision dans le ref labo
  particule_1[2] = vgx + vitesse_*cos(theta);
  particule_1[3] = vgy + vitesse_*sin(theta);
  particule_2[2] = vgx - vitesse_*cos(theta);
  particule_2[3] = vgy - vitesse_*sin(theta);
}



void choc_mur_bas(double * particule)
{ 
  double vitesse = sqrt(particule[2]*particule[2]+particule[3]*particule[3]);
  double theta = M_PI*rand()/RAND_MAX;
  particule[2] = vitesse*cos(theta);
  particule[3] = vitesse*sin(theta);
}


void choc_mur_haut(double * particule, double vitesse_mur)
{ particule[2] = particule[2]-vitesse_mur;
  double vitesse = sqrt(particule[2]*particule[2]+particule[3]*particule[3]);
  double theta = M_PI*rand()/RAND_MAX;
  particule[2] = vitesse_mur+vitesse*cos(theta);
  particule[3] = -vitesse*sin(theta);
}


double distance_deux_particule(double * particule_1, double * particule_2)
{ return sqrt((particule_1[0]-particule_2[0])*(particule_1[0]-particule_2[0])+(particule_1[1]-particule_2[1])*(particule_1[1]-particule_2[1]));
}


void mouvement(double * particule, double dt)
{ particule[0] = particule[0] + particule[2]*dt;
  particule[1] = particule[1] + particule[3]*dt;
}





int main()
{
  int i, j, k;
  srand(time(NULL));

  ofstream write("couette_plan.txt",ios::out);
  write.precision(6);
  ofstream write_h("histo_vitesse.txt",ios::out);
  write_h.precision(6);
  

  int nb_particule = 5000;
  int nb_particule_ecrite = 1000;


  double L = 2.0;  //longueur tube
  double l = 1.;   //largeur tube
  double d = 0.025;  //diametre particule

  double v_max = 1.; //vitesse max des paticule à l'instant 0 (température) 
  double v_mur = 1.; //vitesse du mur

  double dt = 0.0025;  //pas de temps
  double nb_step = 10000; //nb etape
  int pas_ecriture = 10;

  int n_histo = 10;
  double * histo_vitesse_moyenne = new double[n_histo];
  double * histo_n = new double[n_histo];


  //creation des particules
  double ** particule = new double*[nb_particule];
  double vitesse, theta;
  for(i=0;i<nb_particule;i++)
  { particule[i] = new double[4];
    particule[i][0] = L*rand()/RAND_MAX;
    particule[i][1] = l*rand()/RAND_MAX;
    vitesse = v_max*rand()/RAND_MAX;
    theta = 2*M_PI*rand()/RAND_MAX;
    particule[i][2] = vitesse*cos(theta);
    particule[i][3] = vitesse*sin(theta);
  }





  for(i=0;i<nb_step;i++)
  { //ecriture des position
    if( int(1.*i/pas_ecriture)*pas_ecriture==i )
    { cout << "ecriture " << i << endl;
      for(j=0;j<nb_particule_ecrite;j++)
      { write << setw(13) << particule[j][0] << setw(13) << particule[j][1] << setw(13) << particule[j][2] << setw(13) << particule[j][3] << endl; }
      write << " " << endl;
      //calcul histo
      for(j=0;j<n_histo;j++) 
      { histo_vitesse_moyenne[j] = 0.; histo_n[j]=0.; }
      for(j=0;j<nb_particule;j++)
      { k = int(n_histo/l*particule[j][1]);
        if(k>=0 && k<n_histo) 
        { histo_vitesse_moyenne[k] = histo_vitesse_moyenne[k] + particule[j][2]; 
          histo_n[k]=histo_n[k]+1.;
        }
      }
      for(j=0;j<n_histo;j++)
      { histo_vitesse_moyenne[j]=histo_vitesse_moyenne[j]/histo_n[k];
        write_h << 1.0*j*l/n_histo << "  " << 0 << endl;
        write_h << 1.0*j*l/n_histo << "  " << histo_vitesse_moyenne[j] << endl;
        write_h << 1.0*(j+1)*l/n_histo << "  " << histo_vitesse_moyenne[j] << endl;
        write_h << 1.0*(j+1)*l/n_histo << "  " << 0 << endl;
      }
      write_h << " " << endl;
    }
    //test s'il y a des trucs à faire
    for(j=0;j<nb_particule;j++)
    { if(particule[j][0]<0) { particule[j][0]=particule[j][0]+L; }
      if(particule[j][0]>L) { particule[j][0]=particule[j][0]-L; }
      if(particule[j][1]<0) { choc_mur_bas(particule[j]); }
      if(particule[j][1]>l) { choc_mur_haut(particule[j],v_mur); }
      for(k=j+1;k<nb_particule;k++)
      { if( distance_deux_particule(particule[j],particule[k])<d ) 
        { choc_deux_particule(particule[j],particule[k]); }
      }
    }
    //move
    for(j=0;j<nb_particule;j++)
    { mouvement(particule[j],dt); }
  }

  write.close();
  write_h.close();



  ofstream gnu("affichage.gnu",ios::out);
  gnu << "set term png size 900,300" << endl;
  gnu << "set size ratio 1./3." << endl;
  gnu << "set border lw 4" << endl;
  gnu << "set nokey" << endl; 
  gnu << "set notics" << endl;
  gnu << "set xrange[0:" << 3 << "]" << endl;
  gnu << "set yrange[0:" << 1 << "]" << endl;
  gnu << "set arrow from 2, graph 0 to 2, graph 1 nohead lw 4" << endl;
  
  for(i=0;i<nb_step/pas_ecriture;i++)
  { gnu << "set output 'image_" << i << ".png'" << endl;
    gnu << "plot 'couette_plan.txt' using 1:2 every :::" << i << "::" << i << " pt 7, 'histo_vitesse.txt' using ($2+2):1 every :::" << i << "::" << i << " w l lw 3" << endl;
  }
  gnu.close();




  return 0;
}
