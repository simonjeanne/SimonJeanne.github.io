import numpy as np
from numpy import where
import matplotlib.pyplot as plt


def rect(x):
    return where(abs(x)<=0.5, 1, 0)



c = 1.
longeur_onde = 0.1
k = 2*np.pi/longeur_onde
w = c*k
longueur_paquet_onde=100




for i in range(0,50):

    delta_=0.1*i
    delta=delta_*longeur_onde

    t = np.linspace(-0.5, 0.5, 500)
    y1 = np.cos(k*(-delta/2.)-w*t)*rect((k*(-delta/2.)-w*t)/k/longueur_paquet_onde)
    y2 = np.cos(k*(+delta/2.)-w*t)*rect((k*(+delta/2.)-w*t)/k/longueur_paquet_onde)
    y_tot = y1+y2

    fig = plt.figure()
    fig.subplots_adjust(top=0.9)
    ax1 = fig.add_subplot(211)
    ax1.set_ylim(-1, 1)
    line1, = ax1.plot(t, y1,dashes=[6, 2])
    line2, = ax1.plot(t, y2,dashes=[6, 2])
    ax1.set_ylabel('E')
    title = "delta = " + str(delta_) + "*lambda"
    ax1.set_title(title)


    ax2 = fig.add_subplot(212)
    ax2.set_ylim(-2, 2)
    line3, = ax2.plot(t, y_tot,color='black')
    ax2.set_xlabel('temps (s)')
    ax2.set_ylabel('E total')

    fig_name = "OPPM_delta_" + str(i) + ".png"
    fig.savefig(fig_name)
    plt.close()
